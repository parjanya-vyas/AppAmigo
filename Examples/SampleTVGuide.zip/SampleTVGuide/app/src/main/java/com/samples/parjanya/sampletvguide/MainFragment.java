package com.samples.parjanya.sampletvguide;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.libraries.parjanya.recorderviewslib.ExtendedRecorderClasses.Widgets.RecorderSpinner;

import java.util.ArrayList;
import java.util.Iterator;

public class MainFragment extends Fragment implements AdapterView.OnItemSelectedListener{

    RecorderSpinner regionSpinner, languageSpinner, categorySpinner;
    ListView listView;
    TVListAdapter tvListAdapter;
    ArrayList<TVListItem> listItems;
    ArrayAdapter<String> regionAdapter, languageAdapter, categoryAdapter;
    int fragmentType;

    public MainFragment() {
    }

    private void updateListAdapter() {
        if (fragmentType == 1) {
            listItems.add(new TVListItem("Harry Potter", "English", "Fantasy", "UK", "XYZ", "ABC", "BCD", "SDF", R.drawable.harry));
            listItems.add(new TVListItem("Sherlock Holmes", "English", "Crime", "UK", "XYZ", "ABC", "BCD", "SDF", R.drawable.sherlock));
            listItems.add(new TVListItem("Blade Runner", "English", "Fantasy", "UK", "XYZ", "ABC", "BCD", "SDF", R.drawable.runner));
            listItems.add(new TVListItem("Incredibles", "English", "Action", "USA", "XYZ", "ABC", "BCD", "SDF", R.drawable.incredibles));
            listItems.add(new TVListItem("The Godfather", "English", "Crime", "USA", "XYZ", "ABC", "BCD", "SDF", R.drawable.godfather));
            listItems.add(new TVListItem("Mission Impossible", "English", "Action", "USA", "XYZ", "ABC", "BCD", "SDF", R.drawable.mission));
            listItems.add(new TVListItem("The Sweet Hereafter", "English", "Drama", "Canada", "XYZ", "ABC", "BCD", "SDF", R.drawable.sweet));
            listItems.add(new TVListItem("Goin' Down The Road", "English", "Drama", "Canada", "XYZ", "ABC", "BCD", "SDF", R.drawable.road));
            listItems.add(new TVListItem("Incendies", "English", "Drama", "Canada", "XYZ", "ABC", "BCD", "SDF", R.drawable.incendies));
            listItems.add(new TVListItem("Gangs of Wasseypur", "Hindi", "Crime", "India", "XYZ", "ABC", "BCD", "SDF", R.drawable.gangs));
            listItems.add(new TVListItem("Dhoom", "Hindi", "Crime", "India", "XYZ", "ABC", "BCD", "SDF", R.drawable.dhoom));
            listItems.add(new TVListItem("Koi Mil Gaya", "Hindi", "Fantasy", "India", "XYZ", "ABC", "BCD", "SDF", R.drawable.koimilgaya));
            listItems.add(new TVListItem("Bey Yaar", "Gujarati", "Drama", "India", "XYZ", "ABC", "BCD", "SDF", R.drawable.beyyaar));
            listItems.add(new TVListItem("Love Ni Bhavai", "Gujarati", "Romance", "India", "XYZ", "ABC", "BCD", "SDF", R.drawable.love));
            listItems.add(new TVListItem("Chello Divas", "Gujarati", "Comedy", "India", "XYZ", "ABC", "BCD", "SDF", R.drawable.chello));
        } else {
            listItems.add(new TVListItem("Game of Thrones", "English", "Fantasy", "USA", "XYZ", "ABC", "BCD", "SDF", R.drawable.got));
            listItems.add(new TVListItem("Friends", "English", "Comedy", "USA", "XYZ", "ABC", "BCD", "SDF", R.drawable.friends));
            listItems.add(new TVListItem("Big Bang Theory", "English", "Comedy", "USA", "XYZ", "ABC", "BCD", "SDF", R.drawable.bbg));
            listItems.add(new TVListItem("Doctor Who", "English", "Drama", "UK", "XYZ", "ABC", "BCD", "SDF", R.drawable.doctor));
            listItems.add(new TVListItem("Sherlock Holmes", "English", "Crime", "UK", "XYZ", "ABC", "BCD", "SDF", R.drawable.sherlock));
            listItems.add(new TVListItem("The Crown", "English", "Drama", "UK", "XYZ", "ABC", "BCD", "SDF", R.drawable.crown));
            listItems.add(new TVListItem("Trailer Park Boys", "English", "Comedy", "Canada", "XYZ", "ABC", "BCD", "SDF", R.drawable.boys));
            listItems.add(new TVListItem("The Kids in the Hall", "English", "Comedy", "Canada", "XYZ", "ABC", "BCD", "SDF", R.drawable.kids));
            listItems.add(new TVListItem("Bade Achhe Lagte Hai", "Hindi", "Romance", "India", "XYZ", "ABC", "BCD", "SDF", R.drawable.achhe));
            listItems.add(new TVListItem("Yeh Hai Mohabbatein", "Hindi", "Romance", "India", "XYZ", "ABC", "BCD", "SDF", R.drawable.mohabbatein));
            listItems.add(new TVListItem("Shaktiman", "Hindi", "Fantasy", "India", "XYZ", "ABC", "BCD", "SDF", R.drawable.shaktimaan));
            listItems.add(new TVListItem("Rasoi Show", "Gujarati", "Skills", "India", "XYZ", "ABC", "BCD", "SDF", R.drawable.rasoi));
            listItems.add(new TVListItem("Preet, Piyu ane Panetar", "Gujarati", "Drama", "India", "XYZ", "ABC", "BCD", "SDF", R.drawable.preet));
        }
    }

    private void applyFilters() {
        tvListAdapter.listItems.clear();
        tvListAdapter.listItems.addAll(listItems);
        String region = (String)regionSpinner.getSelectedItem();
        String language = (String)languageSpinner.getSelectedItem();
        String category = (String)categorySpinner.getSelectedItem();

        if (!category.equalsIgnoreCase("None")) {
            ArrayList<TVListItem> newList = new ArrayList<>(tvListAdapter.listItems);
            for (Iterator<TVListItem> iterator = newList.iterator(); iterator.hasNext();) {
                if (!iterator.next().category.equalsIgnoreCase(category))
                    iterator.remove();
            }
            tvListAdapter.listItems.clear();
            tvListAdapter.listItems.addAll(newList);
        }
        if (!language.equalsIgnoreCase("None")) {
            ArrayList<TVListItem> newList = new ArrayList<>(tvListAdapter.listItems);
            for (Iterator<TVListItem> iterator = newList.iterator(); iterator.hasNext();) {
                if (!iterator.next().language.equalsIgnoreCase(language))
                    iterator.remove();
            }
            tvListAdapter.listItems.clear();
            tvListAdapter.listItems.addAll(newList);
        }
        if (!region.equalsIgnoreCase("None")) {
            ArrayList<TVListItem> newList = new ArrayList<>(tvListAdapter.listItems);
            for (Iterator<TVListItem> iterator = newList.iterator(); iterator.hasNext();) {
                if (!iterator.next().region.equalsIgnoreCase(region))
                    iterator.remove();
            }
            tvListAdapter.listItems.clear();
            tvListAdapter.listItems.addAll(newList);
        }
        tvListAdapter.notifyDataSetChanged();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View fragment = inflater.inflate(R.layout.fragment_main, container, false);
        fragmentType = getArguments().getInt(Constants.WHICH_FRAGMENT_BUNDLE_KEY, -1);

        regionSpinner = fragment.findViewById(R.id.region_spinner);
        languageSpinner = fragment.findViewById(R.id.language_spinner);
        categorySpinner = fragment.findViewById(R.id.category_spinner);
        listView = fragment.findViewById(R.id.fragment_list_view);

        regionAdapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_item, new String[] {"None", "Canada", "USA", "UK", "India"});
        regionAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        languageAdapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_item, new String[] {"None", "English", "Hindi", "Gujarati"});
        languageAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        categoryAdapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_item, new String[] {"None", "Crime", "Romance", "Action", "Fantasy", "Comedy", "Drama","Skills"});
        categoryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        regionSpinner.setAdapter(regionAdapter);
        languageSpinner.setAdapter(languageAdapter);
        categorySpinner.setAdapter(categoryAdapter);

        regionSpinner.setOnItemSelectedListener(this);
        languageSpinner.setOnItemSelectedListener(this);
        categorySpinner.setOnItemSelectedListener(this);

        listItems = new ArrayList<>();
        updateListAdapter();
        tvListAdapter = new TVListAdapter(getActivity(), R.layout.list_item, new ArrayList<>(listItems));
        listView.setAdapter(tvListAdapter);

        return fragment;
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        switch (parent.getId()) {
            case R.id.region_spinner:
                applyFilters();
                break;
            case R.id.language_spinner:
                applyFilters();
                break;
            case R.id.category_spinner:
                applyFilters();
                break;
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
