package com.samples.parjanya.sampletvguide;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

public class HomePagerAdapter extends FragmentStatePagerAdapter {
    private String[] titles = {"TV SHOW", "MOVIE"};

    HomePagerAdapter(FragmentManager fragmentManager) {
        super(fragmentManager);
    }

    @Override
    public Fragment getItem(int position) {
        Fragment mainFragment = new MainFragment();
        Bundle fragmentBundle = new Bundle();
        fragmentBundle.putInt(Constants.WHICH_FRAGMENT_BUNDLE_KEY, position);
        mainFragment.setArguments(fragmentBundle);
        return mainFragment;
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return titles[position];
    }

    @Override
    public int getCount() {
        return 2;
    }
}
