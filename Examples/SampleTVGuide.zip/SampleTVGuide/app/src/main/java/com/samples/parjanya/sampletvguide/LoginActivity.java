package com.samples.parjanya.sampletvguide;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.libraries.parjanya.recorderviewslib.ExtendedRecorderClasses.Activities.RecorderAppCompatActivity;
import com.libraries.parjanya.recorderviewslib.ExtendedRecorderClasses.Widgets.RecorderButton;
import com.libraries.parjanya.recorderviewslib.ExtendedRecorderClasses.Widgets.RecorderTextInputEditText;

public class LoginActivity extends RecorderAppCompatActivity implements View.OnClickListener{

    RecorderTextInputEditText userNameEdit, nameEdit, emailEdit, passwordEdit;
    RecorderButton goButton;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    boolean keepLogin, isRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        userNameEdit = findViewById(R.id.login_username);
        nameEdit = findViewById(R.id.login_name);
        emailEdit = findViewById(R.id.login_email);
        passwordEdit = findViewById(R.id.login_password);
        goButton = findViewById(R.id.login_go);

        keepLogin = getIntent().getBooleanExtra(Constants.LOGIN_KEEP_LOGIN_EXTRA, false);
        isRegister = getIntent().getBooleanExtra(Constants.LOGIN_REGISTER_EXTRA, false);

        if (!isRegister) {
            nameEdit.setVisibility(View.GONE);
            emailEdit.setVisibility(View.GONE);
        }

        goButton.setOnClickListener(this);
        sharedPreferences = getSharedPreferences(Constants.SHARED_PREFERENCE_NAME, MODE_PRIVATE);
    }

    @Override
    public void onClick(View v) {
        Intent intent = new Intent(this, HomeActivity.class);
        if (isRegister) {
            editor = sharedPreferences.edit();
            editor.putString(Constants.SHARED_PREFERENCE_KEY_USERNAME, userNameEdit.getText().toString());
            editor.putString(Constants.SHARED_PREFERENCE_KEY_NAME, nameEdit.getText().toString());
            editor.putString(Constants.SHARED_PREFERENCE_KEY_EMAIL, emailEdit.getText().toString());
            editor.putString(Constants.SHARED_PREFERENCE_KEY_PASSWORD, passwordEdit.getText().toString());
            editor.putBoolean(Constants.SHARED_PREFERENCE_KEY_KEEP_LOGIN, keepLogin);
            editor.apply();
            startActivity(intent);
            finish();
        } else {
            if (sharedPreferences.getString(Constants.SHARED_PREFERENCE_KEY_USERNAME, "").equals(userNameEdit.getText().toString())
                    && sharedPreferences.getString(Constants.SHARED_PREFERENCE_KEY_PASSWORD, "").equals(passwordEdit.getText().toString())){
                editor = sharedPreferences.edit();
                editor.putBoolean(Constants.SHARED_PREFERENCE_KEY_KEEP_LOGIN, keepLogin);
                editor.apply();
                startActivity(intent);
                finish();
            } else
                Toast.makeText(this, "Login Failed", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onBackPressed() {
        Intent welIntent = new Intent(this, WelcomeActivity.class);
        startActivity(welIntent);
        finish();
        super.onBackPressed();
    }
}
