package com.samples.parjanya.sampletvguide;

public class Constants {
    public static final String LOGIN_REGISTER_EXTRA = "register";
    public static final String LOGIN_KEEP_LOGIN_EXTRA = "keepLoggedIn";
    public static final String DETAILS_LIST_ITEM_EXTRA = "listItem";
    public static final String DETAILS_FULL_EXTRA = "fullDetails";
    public static final String SHARED_PREFERENCE_NAME = "sharedPref";
    public static final String SHARED_PREFERENCE_KEY_USERNAME = "usernamePref";
    public static final String SHARED_PREFERENCE_KEY_NAME = "namePref";
    public static final String SHARED_PREFERENCE_KEY_EMAIL = "emailPref";
    public static final String SHARED_PREFERENCE_KEY_PASSWORD = "passwordPref";
    public static final String SHARED_PREFERENCE_KEY_KEEP_LOGIN = "keepLoginPref";
    public static final String SHARED_PREFERENCE_KEY_CAT = "SHARED_PREFERENCE_KEY_CAT";
    public static final String SHARED_PREFERENCE_KEY_REG = "SHARED_PREFERENCE_KEY_REG";
    public static final String SHARED_PREFERENCE_KEY_LANG = "SHARED_PREFERENCE_KEY_LANG";
    public static final String SHARED_PREFERENCE_KEY_DIR = "SHARED_PREFERENCE_KEY_DIR";
    public static final String SHARED_PREFERENCE_KEY_PRO = "SHARED_PREFERENCE_KEY_PRO";
    public static final String SHARED_PREFERENCE_KEY_ACT = "SHARED_PREFERENCE_KEY_ACT";
    public static final String SHARED_PREFERENCE_KEY_DET = "SHARED_PREFERENCE_KEY_DET";
    public static final String WHICH_FRAGMENT_BUNDLE_KEY = "whichFragment";
}
