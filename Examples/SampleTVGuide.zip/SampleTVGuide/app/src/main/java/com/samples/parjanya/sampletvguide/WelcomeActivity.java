package com.samples.parjanya.sampletvguide;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;

import com.libraries.parjanya.recorderviewslib.ExtendedRecorderClasses.Activities.RecorderAppCompatActivity;
import com.libraries.parjanya.recorderviewslib.ExtendedRecorderClasses.Widgets.RecorderButton;
import com.libraries.parjanya.recorderviewslib.ExtendedRecorderClasses.Widgets.RecorderSwitch;

public class WelcomeActivity extends RecorderAppCompatActivity implements View.OnClickListener, CompoundButton.OnCheckedChangeListener{

    RecorderButton loginButton, registerButton;
    RecorderSwitch keepLoginSwitch;
    boolean keepLogin = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
        if (getSharedPreferences(Constants.SHARED_PREFERENCE_NAME, MODE_PRIVATE).getBoolean(Constants.SHARED_PREFERENCE_KEY_KEEP_LOGIN, false)) {
            Intent intent = new Intent(this, HomeActivity.class);
            startActivity(intent);
            finish();
        }
        loginButton = findViewById(R.id.welcome_login);
        registerButton = findViewById(R.id.welcome_register);
        keepLoginSwitch = findViewById(R.id.welcome_signed_in_switch);

        loginButton.setOnClickListener(this);
        registerButton.setOnClickListener(this);
        keepLoginSwitch.setOnCheckedChangeListener(this);
    }

    @Override
    public void onClick(View v) {
        Intent loginIntent = new Intent(this, LoginActivity.class);
        loginIntent.putExtra(Constants.LOGIN_KEEP_LOGIN_EXTRA, keepLogin);
        switch (v.getId()) {
            case R.id.welcome_login:
                loginIntent.putExtra(Constants.LOGIN_REGISTER_EXTRA, false);
                break;
            case R.id.welcome_register:
                loginIntent.putExtra(Constants.LOGIN_REGISTER_EXTRA, true);
                break;
        }
        startActivity(loginIntent);
        finish();
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        keepLogin = isChecked;
    }
}