package com.samples.parjanya.sampletvguide;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.design.widget.TabLayout;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.libraries.parjanya.recorderviewslib.ExtendedRecorderClasses.Activities.RecorderAppCompatActivity;
import com.libraries.parjanya.recorderviewslib.ExtendedRecorderClasses.Widgets.RecorderViewPager;

public class HomeActivity extends RecorderAppCompatActivity {

    RecorderViewPager mainViewPager;
    TabLayout mainTabLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        mainViewPager = findViewById(R.id.main_view_pager);
        mainTabLayout = findViewById(R.id.main_tab_layout);
        mainViewPager.setAdapter(new HomePagerAdapter(getSupportFragmentManager()));
        mainTabLayout.setupWithViewPager(mainViewPager);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.options, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_options:
                Intent intent = new Intent(this, SettingsActivity.class);
                startActivity(intent);
                break;
            case R.id.menu_help:
                Toast.makeText(this, "HEELLLPPPP!!!!", Toast.LENGTH_SHORT).show();
                break;
            case R.id.menu_about:
                Toast.makeText(this, "This is a sample TV Guide!", Toast.LENGTH_SHORT).show();
                break;
            case R.id.menu_signout:
                SharedPreferences.Editor editor = getSharedPreferences(Constants.SHARED_PREFERENCE_NAME, MODE_PRIVATE).edit();
                editor.putBoolean(Constants.SHARED_PREFERENCE_KEY_KEEP_LOGIN, false);
                editor.apply();
                Intent welIntent = new Intent(this, WelcomeActivity.class);
                startActivity(welIntent);
                finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
