package com.samples.parjanya.sampletvguide;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.widget.CompoundButton;

import com.libraries.parjanya.recorderviewslib.ExtendedRecorderClasses.Activities.RecorderAppCompatActivity;
import com.libraries.parjanya.recorderviewslib.ExtendedRecorderClasses.Widgets.RecorderCheckBox;

public class SettingsActivity extends RecorderAppCompatActivity implements CompoundButton.OnCheckedChangeListener{

    RecorderCheckBox cat, reg, lang, dir, prod, act, det;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        sharedPreferences = getSharedPreferences(Constants.SHARED_PREFERENCE_NAME, MODE_PRIVATE);

        cat = findViewById(R.id.catCheck);
        reg = findViewById(R.id.regCheck);
        lang = findViewById(R.id.langCheck);
        dir = findViewById(R.id.dirCheck);
        prod = findViewById(R.id.prodCheck);
        act = findViewById(R.id.actCheck);
        det = findViewById(R.id.detCheck);

        cat.setChecked(sharedPreferences.getBoolean(Constants.SHARED_PREFERENCE_KEY_CAT,true));
        reg.setChecked(sharedPreferences.getBoolean(Constants.SHARED_PREFERENCE_KEY_REG,true));
        lang.setChecked(sharedPreferences.getBoolean(Constants.SHARED_PREFERENCE_KEY_LANG,true));
        dir.setChecked(sharedPreferences.getBoolean(Constants.SHARED_PREFERENCE_KEY_DIR,true));
        prod.setChecked(sharedPreferences.getBoolean(Constants.SHARED_PREFERENCE_KEY_PRO,true));
        act.setChecked(sharedPreferences.getBoolean(Constants.SHARED_PREFERENCE_KEY_ACT,true));
        det.setChecked(sharedPreferences.getBoolean(Constants.SHARED_PREFERENCE_KEY_DET,true));

        cat.setOnCheckedChangeListener(this);
        reg.setOnCheckedChangeListener(this);
        lang.setOnCheckedChangeListener(this);
        dir.setOnCheckedChangeListener(this);
        prod.setOnCheckedChangeListener(this);
        act.setOnCheckedChangeListener(this);
        det.setOnCheckedChangeListener(this);
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        editor = sharedPreferences.edit();
        switch (buttonView.getId()) {
            case R.id.catCheck: editor.putBoolean(Constants.SHARED_PREFERENCE_KEY_CAT, isChecked); break;
            case R.id.regCheck: editor.putBoolean(Constants.SHARED_PREFERENCE_KEY_REG, isChecked); break;
            case R.id.langCheck: editor.putBoolean(Constants.SHARED_PREFERENCE_KEY_LANG, isChecked); break;
            case R.id.dirCheck: editor.putBoolean(Constants.SHARED_PREFERENCE_KEY_DIR, isChecked); break;
            case R.id.prodCheck: editor.putBoolean(Constants.SHARED_PREFERENCE_KEY_PRO, isChecked); break;
            case R.id.actCheck: editor.putBoolean(Constants.SHARED_PREFERENCE_KEY_ACT, isChecked); break;
            case R.id.detCheck: editor.putBoolean(Constants.SHARED_PREFERENCE_KEY_DET, isChecked); break;
        }
        editor.apply();
    }
}
