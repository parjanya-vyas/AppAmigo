package com.samples.parjanya.sampletvguide;

import android.os.Parcel;
import android.os.Parcelable;

public class TVListItem implements Parcelable{
    public String itemTitle, language, category, region, director, producer, actor, details;
    public int imageResource;

    TVListItem(String itemTitle, String language, String category, String region, String director, String producer,
               String actor, String details, int imageResource) {
        this.itemTitle = itemTitle;
        this.language = language;
        this.category = category;
        this.region = region;
        this.director = director;
        this.producer = producer;
        this.actor = actor;
        this.details = details;
        this.imageResource = imageResource;
    }

    private TVListItem(Parcel in) {
        Object arr[] = in.readArray(getClass().getClassLoader());
        this.itemTitle = arr[0].toString();
        this.language = arr[1].toString();
        this.category = arr[2].toString();
        this.region = arr[3].toString();
        this.director = arr[4].toString();
        this.producer = arr[5].toString();
        this.actor = arr[6].toString();
        this.details = arr[7].toString();
        this.imageResource = Integer.parseInt(arr[8].toString());
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Parcelable.Creator<TVListItem> CREATOR = new Parcelable.Creator<TVListItem>() {
        public TVListItem createFromParcel(Parcel in) {
            return new TVListItem(in);
        }

        public TVListItem[] newArray(int size) {
            return new TVListItem[size];
        }
    };

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        String arr[] = {itemTitle, language, category, region, director, producer, actor, details, Integer.toString(imageResource)};
        dest.writeArray(arr);
    }
}
