package com.samples.parjanya.sampletvguide;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.libraries.parjanya.recorderviewslib.ExtendedRecorderClasses.Activities.RecorderAppCompatActivity;
import com.libraries.parjanya.recorderviewslib.ExtendedRecorderClasses.Widgets.RecorderImageView;

public class DetailsActivity extends RecorderAppCompatActivity {

    TVListItem listItem;
    boolean isFull;

    SharedPreferences preferences;

    RecorderImageView imageView;
    TextView titleText, catText, langText, regText, directText, prodText, actorText, detText;
    LinearLayout bigParent, categoryParent, languageParent, regionParent, directorParent, producerParent, actorParent, detailsParent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        preferences = getSharedPreferences(Constants.SHARED_PREFERENCE_NAME, MODE_PRIVATE);

        imageView = findViewById(R.id.details_image);
        titleText = findViewById(R.id.details_title);

        catText = findViewById(R.id.category_text);
        langText = findViewById(R.id.language_text);
        regText = findViewById(R.id.region_text);
        directText = findViewById(R.id.director_text);
        prodText = findViewById(R.id.producer_text);
        actorText = findViewById(R.id.actor_text);
        detText = findViewById(R.id.details_text);

        bigParent = findViewById(R.id.big_parent);
        categoryParent = findViewById(R.id.category_parent);
        languageParent = findViewById(R.id.language_parent);
        regionParent = findViewById(R.id.region_parent);
        directorParent = findViewById(R.id.director_parent);
        producerParent = findViewById(R.id.producer_parent);
        actorParent = findViewById(R.id.actor_parent);
        detailsParent = findViewById(R.id.details_parent);

        listItem = getIntent().getParcelableExtra(Constants.DETAILS_LIST_ITEM_EXTRA);
        isFull = getIntent().getBooleanExtra(Constants.DETAILS_FULL_EXTRA, true);

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(DetailsActivity.this, titleText.getText().toString(), Toast.LENGTH_SHORT).show();
            }
        });

        imageView.setImageResource(listItem.imageResource);
        titleText.setText(listItem.itemTitle);
        catText.setText(listItem.category);
        langText.setText(listItem.language);
        regText.setText(listItem.region);
        directText.setText(listItem.director);
        prodText.setText(listItem.producer);
        actorText.setText(listItem.actor);
        detText.setText(listItem.details);

        if (!isFull) {
            imageView.getLayoutParams().height = LinearLayout.LayoutParams.MATCH_PARENT;
            imageView.getLayoutParams().width = LinearLayout.LayoutParams.MATCH_PARENT;
            imageView.requestLayout();
        }

        if (!preferences.getBoolean(Constants.SHARED_PREFERENCE_KEY_CAT, true))
            categoryParent.setVisibility(View.GONE);
        if (!preferences.getBoolean(Constants.SHARED_PREFERENCE_KEY_LANG, true))
            languageParent.setVisibility(View.GONE);
        if (!preferences.getBoolean(Constants.SHARED_PREFERENCE_KEY_REG, true))
            regionParent.setVisibility(View.GONE);
        if (!preferences.getBoolean(Constants.SHARED_PREFERENCE_KEY_DIR, true))
            directorParent.setVisibility(View.GONE);
        if (!preferences.getBoolean(Constants.SHARED_PREFERENCE_KEY_PRO, true))
            producerParent.setVisibility(View.GONE);
        if (!preferences.getBoolean(Constants.SHARED_PREFERENCE_KEY_ACT, true))
            actorParent.setVisibility(View.GONE);
        if (!preferences.getBoolean(Constants.SHARED_PREFERENCE_KEY_DET, true))
            detailsParent.setVisibility(View.GONE);
    }
}
