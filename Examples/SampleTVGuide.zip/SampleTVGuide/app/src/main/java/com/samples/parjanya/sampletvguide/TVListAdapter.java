package com.samples.parjanya.sampletvguide;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.libraries.parjanya.recorderviewslib.ExtendedRecorderClasses.Widgets.RecorderLinearLayout;

import java.util.ArrayList;

public class TVListAdapter extends ArrayAdapter<TVListItem>{
    ArrayList<TVListItem> listItems;
    Context context;
    int layoutResource;

    TVListAdapter(Context context, int layoutResource, ArrayList<TVListItem> listItems) {
        super(context, layoutResource, listItems);
        this.listItems = listItems;
        this.context = context;
        this.layoutResource = layoutResource;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null){
            LayoutInflater layoutInflater = (LayoutInflater) getContext()
                    .getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
            convertView = layoutInflater.inflate(R.layout.list_item, null, false);

        }
        final TVListItem listItem = getItem(position);
        ImageView imageView = convertView.findViewById(R.id.list_item_image);
        TextView textView = convertView.findViewById(R.id.list_item_text);
        RecorderLinearLayout parentLayout = convertView.findViewById(R.id.parent_list_item);

        imageView.setImageResource(listItem.imageResource);
        textView.setText(listItem.itemTitle);
        parentLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, DetailsActivity.class);
                intent.putExtra(Constants.DETAILS_LIST_ITEM_EXTRA, listItem);
                intent.putExtra(Constants.DETAILS_FULL_EXTRA, true);
                context.startActivity(intent);

            }
        });
        parentLayout.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Intent intent = new Intent(context, DetailsActivity.class);
                intent.putExtra(Constants.DETAILS_LIST_ITEM_EXTRA, listItem);
                intent.putExtra(Constants.DETAILS_FULL_EXTRA, false);
                context.startActivity(intent);
                return true;
            }
        });

        return convertView;
    }
}
